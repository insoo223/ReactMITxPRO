function Products(){
    return (
        <div>
            <h3>Products Component</h3>
            <p>List of the the product we make</p>
        </div>
    );
}