function About(){
    return (
        <div>
            <h3>About Component</h3>
            <p>This our story</p>
        </div>
    );
}