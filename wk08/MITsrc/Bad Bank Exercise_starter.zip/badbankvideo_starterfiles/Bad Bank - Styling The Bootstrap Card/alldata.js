function AllData(){
  return (
    <>
    <h1>All Data</h1>
    </>
  );
}
