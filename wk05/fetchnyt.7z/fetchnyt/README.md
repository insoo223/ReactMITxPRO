# Purpose
List up New York Times section list per your type-in section name at input field. 

# Limitation
This project is in-progress. To update section name, open notepad type in NYT section i.e. Sports, Movies, Arts, Books etc and copy the whole word and poste it to the web input field. No need to click submit button. The page will bring you NYT section articles newest first order. I will keep improving it.

# Referece 
This project is based on "Build a News App with the NYTimes API & React JS" https://javascript.plainenglish.io/build-a-news-app-with-the-nytimes-api-react-js-c3b4440ede7f. The original code displays tile map of articles, but mine is list oriented.

# Getting Started with Create React App
npx create-react-app fetchnyt
cd fetchnyt

fetchnyt is project folder and you can change for your own purpose.

![image](https://user-images.githubusercontent.com/13712996/117990813-7aa4cc00-b378-11eb-9c33-13355d61134b.png)
