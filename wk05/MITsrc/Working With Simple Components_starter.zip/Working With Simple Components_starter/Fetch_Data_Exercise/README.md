# dataFetch
Uses useEffect and useReduce to manage fetch of online data
